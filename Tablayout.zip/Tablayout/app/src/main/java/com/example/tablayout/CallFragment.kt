package com.example.tablayout

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import java.util.ArrayList

class CallFragment : Fragment()
{
    lateinit var list1: MutableList<Model2>
    lateinit var listView: ListView

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        val view = inflater.inflate(R.layout.fragment_call, container, false)
        listView = view.findViewById(R.id.list1)
        list1 = ArrayList()

        list1.add(Model2(R.drawable.savan, "Savan Yadav","97142 86303"))
        list1.add(Model2(R.drawable.param, "Param Mashru","95120 17676"))
        list1.add(Model2(R.drawable.chintan, "Chintan Nakum","99744 22743"))
        list1.add(Model2(R.drawable.tejas, "Tejas Chauhan","96624 23157"))

        val adapter = CallAdapter(requireContext(), list1)
        listView.adapter = adapter

      /*  listView.setOnClickListener {
            val position = 0
            val phoneNumber = list1[position].phoneNumber
            openDialer(phoneNumber)
        }*/
        listView.setOnItemClickListener { adapterView, view, i, l ->

            val position = 0
            val phoneNumber = list1[position].phoneNumber
            openDialer(phoneNumber)


        }


        return view
    }

    private fun openDialer(phoneNumber: String) {
        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
        startActivity(dialIntent)
    }

}