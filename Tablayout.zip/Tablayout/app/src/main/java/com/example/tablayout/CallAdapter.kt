package com.example.tablayout

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class CallAdapter(var context:Context, var list1: MutableList<Model2>) : BaseAdapter()
{
    override fun getCount(): Int
    {
        return list1.size
    }

    override fun getItem(p0: Int): Any
    {
        return  list1.get(p0)
    }

    override fun getItemId(p0: Int): Long
    {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View
    {
        val layout = LayoutInflater.from(context)
        val view = layout.inflate(R.layout.design,p2, false)

        val txt1: TextView = view.findViewById(R.id.txt1)
        val txt2: TextView = view.findViewById(R.id.txt2)
        val image: ImageView = view.findViewById(R.id.img)

        // Set data
        txt1.text = list1[p0].title
        txt2.text = list1[p0].phoneNumber
        image.setImageResource(list1[p0].image)

        return view
    }


}
