package com.example.tablayout


class Model2(var image:Int, var title:String, var phoneNumber: String) {
}