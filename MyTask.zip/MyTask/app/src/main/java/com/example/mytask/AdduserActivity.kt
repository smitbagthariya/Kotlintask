package com.example.mytask

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import net.gotev.uploadservice.MultipartUploadRequest
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class   AdduserActivity : AppCompatActivity() {

    private lateinit var edtName: EditText
    private lateinit var edtPrice: EditText
    private lateinit var edtDescription: EditText
    private lateinit var imgProduct: ImageView
    private lateinit var btnAddProduct: Button
    private lateinit var apiinterface: Apiinterface

    private var imageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adduser)

        edtName = findViewById(R.id.edt1)
        edtPrice = findViewById(R.id.edt2)
        edtDescription = findViewById(R.id.edt3)
        imgProduct = findViewById(R.id.img)
        btnAddProduct = findViewById(R.id.btn1)

        apiinterface = ApiClient.getApiClient().create(Apiinterface::class.java)

        imgProduct.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, 1)
        }

        btnAddProduct.setOnClickListener {
            val pname = edtName.text.toString()
            val pprice = edtPrice.text.toString()
            val pdesc = edtDescription.text.toString()

            if (pname.isEmpty() || pprice.isEmpty() || pdesc.isEmpty() || imageUri == null) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            imageUri?.let { uri ->
                val filePath = getPathFromUri(uri)
                if (filePath != null) {
                    uploadImage(pname, pprice, pdesc, pstatus = "1", filePath)
                } else {
                    Toast.makeText(this, "Invalid Image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && data != null) {
            imageUri = data.data
            imgProduct.setImageURI(imageUri)
        }
    }

    private fun uploadImage(pname: String, pprice: String, pdesc: String,pstatus:String, filePath: String) {
        MultipartUploadRequest(this, "https://prakrutitech.buzz/Rahul/insert.php")
            .addFileToUpload(filePath, "pimage")
            .addParameter("pname", pname)
            .addParameter("pprice", pprice)
            .addParameter("pdes", pdesc)
            .addParameter("pstatus", pstatus)
            .setMaxRetries(2)
            .startUpload()

        val call = apiinterface.insertProduct(pimage = imageUri.toString(),pname,pprice,pdesc,pstatus)

        call.enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    Toast.makeText(applicationContext, "Product Added", Toast.LENGTH_LONG).show()
                    startActivity(Intent(applicationContext, ViewActivity::class.java))
                } else {
                    Toast.makeText(applicationContext, "Upload Failed", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                Toast.makeText(applicationContext, "Upload Failed: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun getPathFromUri(uri: Uri): String? {
        val cursor = contentResolver.query(uri, arrayOf(MediaStore.Images.Media.DATA), null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                return it.getString(it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
            }
        }
        return null
    }
}
