package com.example.mytask

data class Model(
    val email: String?,
    val password: String?
)
