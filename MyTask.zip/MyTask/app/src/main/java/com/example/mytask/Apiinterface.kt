package com.example.mytask

import android.net.Uri
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

interface Apiinterface {
    @FormUrlEncoded
    @POST("signup.php")
    fun signup(
        @Field("name") name: String,
        @Field("surname") surname: String,
        @Field("email") email: String,
        @Field("gender") gender: String,
        @Field("mobile") mobile: String,
        @Field("password") password: String
    ): Call<Void>

    @FormUrlEncoded
    @POST("signin.php")
    fun signin(@Field("email") email: String, @Field("password") password: String): Call<Model>

    @GET("productview.php")
    fun getdata() : Call<List<ProductModel>>



    @FormUrlEncoded
    @POST("productupdate.php")
    fun updatedata(
        @Field("pid") pid: Int,
        @Field("pname") pname: String,
        @Field("pprice") pprice: String,
        @Field("pdesc") pdesc: String,

    ): Call<Void>

    @FormUrlEncoded
    @POST("productinsert.php")
    fun insertProduct(

        @Field("pimage") pimage:String,
        @Field("pname") pname:String,
        @Field("pprice") pprice:String,
        @Field("pdesc") pdesc:String,
        @Field("pstatus") pstatus:String
    ): Call<Void>


    @FormUrlEncoded
    @POST("productdelete.php")
    fun deleteProduct(@Field("id") id: String): Call<Void>


}
