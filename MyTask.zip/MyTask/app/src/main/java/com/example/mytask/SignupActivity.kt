package com.example.mytask

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mytask.databinding.ActivitySignupBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class SignupActivity : AppCompatActivity()
{
    private lateinit var binding: ActivitySignupBinding
    lateinit var apiinterface: Apiinterface

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        apiinterface = ApiClient.getApiClient().create(Apiinterface::class.java)

        binding.btn1.setOnClickListener {

            var name = binding.edt1.text.toString()
            var surname = binding.edt2.text.toString()
            var email = binding.edt3.text.toString()
            var gender = binding.edt4.text.toString()
            var mobile = binding.edt5.text.toString()
            var pass = binding.edt6.text.toString()
            var call = apiinterface.signup(name,surname,email,gender,mobile,pass)

            call.enqueue(object:Callback<Void>
            {
                override fun onResponse(call: Call<Void>, response: Response<Void>) {

                    Toast.makeText(applicationContext, "Registration Done", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(applicationContext, MainActivity::class.java))
                }

                override fun onFailure(call: Call<Void>, t: Throwable)
                {
                    Toast.makeText(applicationContext, "Registration Fail", Toast.LENGTH_SHORT).show()

                }
            })

        }


    }
}