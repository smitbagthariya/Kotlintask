package com.example.mytask

data class ProductModel(
    val pid: String,
    val pname: String,
    val pprice: String,
    val pdesc: String,
    val imageUrl: String
)
