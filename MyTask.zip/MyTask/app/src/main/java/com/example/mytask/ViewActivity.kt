package com.example.mytask

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mytask.databinding.ActivityViewBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewActivity : AppCompatActivity() {
    lateinit var binding: ActivityViewBinding
    private lateinit var apiinterface: Apiinterface
    private lateinit var ProductAdapter: ProductAdapter
    private var productList: MutableList<ProductModel> = mutableListOf()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.tool)


        val sharedPreferences = getSharedPreferences("USER_SESSION", MODE_PRIVATE)
        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)

        if (!isLoggedIn) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        ProductAdapter = ProductAdapter(this, productList)
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = ProductAdapter

        fetchData()

        binding.btnAddProduct.setOnClickListener {
            val intent = Intent(this, AdduserActivity::class.java)
            startActivity(intent)
        }
    }


    private fun fetchData() {
        apiinterface = ApiClient.getApiClient().create(Apiinterface::class.java)
        val call: Call<List<ProductModel>> = apiinterface.getdata()

        call.enqueue(object : Callback<List<ProductModel>> {
            override fun onResponse(
                call: Call<List<ProductModel>>,
                response: Response<List<ProductModel>>
            ) {
                if (response.isSuccessful) {
                    productList.clear()
                    productList.addAll(response.body() ?: emptyList())
                    ProductAdapter.notifyDataSetChanged()
                }
            }

            override fun onFailure(call: Call<List<ProductModel>>, t: Throwable) {
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.logout -> {
                val sharedPreferences = getSharedPreferences("USER_SESSION", MODE_PRIVATE)
                val editor = sharedPreferences.edit()
                editor.clear()
                editor.apply()

                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }


}
