package com.example.mytask

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ProductAdapter(var context: Context, var productList: MutableList<ProductModel>) :
    RecyclerView.Adapter<ProductAdapter.Productview>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Productview {
        val layout = LayoutInflater.from(parent.context)
        val layoutView = layout.inflate(R.layout.design, parent, false)
        return Productview(layoutView)
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    override fun onBindViewHolder(holder: Productview, position: Int) {
        val product = productList[position]
        holder.txt1.text = product.pname
        holder.txt2.text = product.pprice
        holder.txt3.text = product.pdesc

        val fullImageUrl = "https://yourserver.com" + product.imageUrl  // Adjust base URL if needed

        Log.d("ImageURL", "Loading Image: $fullImageUrl")

        Glide.with(context)
            .load(fullImageUrl)
            .into(holder.imgProduct)

        holder.itemView.setOnClickListener {
            showdialog(product, position)
        }
    }

    private fun showdialog(product: ProductModel, position: Int) {
        val options = arrayOf("Update", "Delete")
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Choose an action")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> {
                    val intent = Intent(context, UpdateActivity::class.java)
                    intent.putExtra("id", product.pid)
                    intent.putExtra("pname", product.pname)
                    intent.putExtra("pprice", product.pprice)
                    intent.putExtra("pdesc", product.pdesc)
                    intent.putExtra("imageUrl", product.imageUrl)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                }
                1 -> {
                    deleteProduct(product.pid, position)
                }
            }
        }
        builder.show()
    }

    private fun deleteProduct(id: String, position: Int) {
        val apiInterface = ApiClient.getApiClient().create(Apiinterface::class.java)
        val call = apiInterface.deleteProduct(id)

        call.enqueue(object : retrofit2.Callback<Void> {
            override fun onResponse(call: retrofit2.Call<Void>, response: retrofit2.Response<Void>) {
                if (response.isSuccessful) {
                    Toast.makeText(context, "Product Deleted", Toast.LENGTH_SHORT).show()
                    productList.removeAt(position)
                    notifyItemRemoved(position)
                }
            }

            override fun onFailure(call: retrofit2.Call<Void>, t: Throwable) {
                Toast.makeText(context, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    class Productview(view: View) : RecyclerView.ViewHolder(view) {
        var txt1: TextView = view.findViewById(R.id.tvProductName)
        var txt2: TextView = view.findViewById(R.id.tvProductPrice)
        var txt3: TextView = view.findViewById(R.id.tvProductDescription)
        var imgProduct: ImageView = view.findViewById(R.id.ivProductImage)
    }
}
