package com.example.mytask

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mytask.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var apiinterface: Apiinterface
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        apiinterface = ApiClient.getApiClient().create(Apiinterface::class.java)
        sharedPreferences = getSharedPreferences("USER_SESSION", MODE_PRIVATE)

        // 🔹 Debug: Check if user is already logged in
        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
        Log.d("DEBUG", "Login Status: $isLoggedIn")

        if (isLoggedIn) {
            Log.d("DEBUG", "User already logged in, redirecting to ViewActivity")
            startActivity(Intent(this, ViewActivity::class.java))
            finish()
        }

        binding.btn1.setOnClickListener {
            val email = binding.edt1.text.toString()
            val pass = binding.edt2.text.toString()

            if (email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(applicationContext, "Please enter email and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val call = apiinterface.signin(email, pass)
            call.enqueue(object : Callback<Model> {
                override fun onResponse(call: Call<Model>, response: Response<Model>) {
                    Log.d("DEBUG", "API Response Code: ${response.code()}")

                    if (response.isSuccessful && response.body() != null) {
                        val model = response.body()!!
                        Log.d("DEBUG", "Login Successful")

                        val editor = sharedPreferences.edit()
                        editor.putBoolean("isLoggedIn", true)
                        editor.putString("email", model.email)
                        editor.apply()

                        Toast.makeText(applicationContext, "Login Successful", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(applicationContext, ViewActivity::class.java))
                        finish()
                    } else {
                        Log.d("DEBUG", "Invalid login credentials: ${response.errorBody()?.string()}")
                        Toast.makeText(applicationContext, "Invalid Credentials", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<Model>, t: Throwable) {
                    Log.d("DEBUG", "Login Failed: ${t.message}")
                    Toast.makeText(applicationContext, "Login Failed", Toast.LENGTH_SHORT).show()
                }
            })
        }

        binding.btn2.setOnClickListener {
            startActivity(Intent(applicationContext, SignupActivity::class.java))
        }
    }
}
